package com.waracle.androidtest.dataItems;

/**
 * Created by David on 12/2/2016.
 */
public class CakeItems {
    private String title,desc, image;

    public CakeItems(){}

    public CakeItems(String t, String d, String i)
    {
        this.title = t;
        this.desc = d;
        this.image = i;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }
    public String getTitle()
    {
        return title;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }
    public String getDesc()
    {
        return desc;
    }

    public void setImage(String image)
    {
        this.image = image;
    }
    public String getImage()
    {
        return image;
    }
}
