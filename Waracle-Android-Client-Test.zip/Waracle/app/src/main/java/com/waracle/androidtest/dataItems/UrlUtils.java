package com.waracle.androidtest.dataItems;

/**
 * Created by David on 12/2/2016.
 */
public class UrlUtils {
    //All URL Strings can be declared here
    public static String JSON_URL = "http://matchedbrands.com/caketest/";
    public static String CAKE_IMAGE_URL = JSON_URL+"/cakesimage/";

    //Nothing was found in this URL
    //public static String JSON_URL = "https://gist.githubusercontent.com/hart88/198f29ec5114a3ec3460/" +"raw/8dd19a88f9b8d24c23d9960f3300d0c917a4f07c/cake.json";

}
