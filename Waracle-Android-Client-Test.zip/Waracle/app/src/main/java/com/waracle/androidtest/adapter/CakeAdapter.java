package com.waracle.androidtest.adapter;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.waracle.androidtest.R;
import com.waracle.androidtest.dataItems.CakeItems;
import com.waracle.androidtest.dataItems.UrlUtils;
import com.waracle.androidtest.httpClient.ImageLoader;

import java.util.List;

/**
 * Created by David on 12/2/2016.
 */
public class CakeAdapter extends BaseAdapter{

    public List<CakeItems> items;
    Activity activity;
    private LayoutInflater inflater;

    public CakeAdapter(Activity activity, List<CakeItems> cakeItemsList)
    {
        this.items = cakeItemsList;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int location) {
        return items.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.list_items, null);

        TextView title = (TextView) convertView.findViewById(R.id.title);
        TextView desc = (TextView) convertView.findViewById(R.id.desc);
        final ImageView image = (ImageView) convertView.findViewById(R.id.image);

        CakeItems item = items.get(position);

        title.setText(item.getTitle());
        desc.setText(item.getDesc());



        String imgUrl = UrlUtils.CAKE_IMAGE_URL+item.getImage();

        Log.d("Res >",imgUrl);

        ImageLoader loaderObj = new ImageLoader(image, imgUrl);
        loaderObj.load();

        return convertView;
    }
}
