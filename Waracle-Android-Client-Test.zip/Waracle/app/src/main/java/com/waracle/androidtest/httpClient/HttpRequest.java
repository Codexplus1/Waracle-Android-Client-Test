package com.waracle.androidtest.httpClient;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by David on 12/2/2016.
 */
public class HttpRequest {

    public HttpRequest(){}

    public final static String TAG = "Exception ";

    public String makeServerRequest(String urlString)
    {
        String responseString = null;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStream in = new BufferedInputStream(conn.getInputStream());

            responseString = StreamToString(in);

        }catch (MalformedURLException e)
        {
            Log.d(TAG, "Response: "+e.getMessage());
        }catch (IOException e)
        {
            Log.d(TAG, "Response: "+e.getMessage());
        }catch (Exception e)
        {
            Log.d(TAG, "Response: "+e.getMessage());
        }

        return responseString;
    }

    public String StreamToString(InputStream stream)
    {
        InputStreamReader inputStream = new InputStreamReader(stream);
        BufferedReader bufferedReader = new BufferedReader(inputStream);
        StringBuilder sb = new StringBuilder();

        String ln;

        try{
            while((ln=bufferedReader.readLine()) != null)
            {
                sb.append(ln).append('\n');
            }
        }catch (IOException e){

        }finally {

            try{
                stream.close();
            }catch(IOException e)
            {
                e.printStackTrace();
            }

        }

        return sb.toString();
    }

}
