package com.waracle.androidtest.httpClient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidParameterException;

/**
 * Created by Riad on 20/05/2015.
 */
public class ImageLoader {

    String ImageUrl;
    ImageView imageView;

    public ImageLoader(ImageView imageView, String url)
    {
        this.ImageUrl = url;
        this.imageView = imageView;
    }

    public void load()
    {
        new ImageRequest(imageView).execute();
    }

    public class ImageRequest extends AsyncTask<String,Void,Bitmap> {
        private WeakReference<ImageView> imageview;
        public ImageRequest(ImageView imv){
            imageview=new WeakReference<ImageView>(imv);
        }

        @Override
        protected Bitmap doInBackground(String... urls) {

            return getBitMapFromUrl(ImageUrl);

        }
        @Override
        protected void onPostExecute(Bitmap result) {
            if((imageview!=null)&&(result!=null)){
                ImageView imgview=imageview.get();

                if(imgview!=null){

                    imgview.setImageBitmap(result);
                }
            }
        }

        private Bitmap getBitMapFromUrl( String imageuri){
            HttpURLConnection connection=null;

            try {
                URL url=new URL(imageuri);
                connection= (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream is=connection.getInputStream();
                Bitmap mybitmap=BitmapFactory.decodeStream(is);

                return mybitmap;


            } catch (MalformedURLException e) {
                e.printStackTrace();
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
            finally {
                if(connection!=null) {
                    connection.disconnect();
                }
            }
        }

    }
}