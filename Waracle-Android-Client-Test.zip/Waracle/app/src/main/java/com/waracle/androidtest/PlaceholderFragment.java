package com.waracle.androidtest;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.waracle.androidtest.adapter.CakeAdapter;
import com.waracle.androidtest.dataItems.CakeItems;
import com.waracle.androidtest.dataItems.UrlUtils;
import com.waracle.androidtest.httpClient.HttpRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by David on 12/2/2016.
 */
public class PlaceholderFragment extends Fragment {

    private View view = null;
    public List<CakeItems> cakeList;

    ListView list;
    CakeAdapter cAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState){ super.onCreate(savedInstanceState);}

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.placeholderfragment, container, false);

        //list
        list = (ListView) view.findViewById(R.id.list);

        //Adapter



        cakeList = new ArrayList<CakeItems>();
        cAdapter = new CakeAdapter(getActivity(), cakeList);
        list.setAdapter(cAdapter);

        new TaskService().execute();

        return  view;
    }

    public class TaskService extends AsyncTask<Void, Void, Void>
    {
        JSONObject resObj = null;

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();

            Toast.makeText(getActivity(), "Processing...", Toast.LENGTH_SHORT).show();

        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpRequest hr = new HttpRequest();
            String response = hr.makeServerRequest(UrlUtils.JSON_URL+"cakes.json");

            Log.d("Data", "in background > "+response);

            try{
                if(response != null) {

                    resObj = new JSONObject(response);

                }
            }catch(JSONException e)
            {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            super.onPostExecute(result);

            setListItemData(resObj);

        }

    }

    public void setListItemData(JSONObject response)
    {
        Log.d("Data", "Res > "+response);

        try {

            if(response != null) {

                JSONArray cakes = response.getJSONArray("cakes");

                for (int i = 0; i < cakes.length(); i++) {
                    CakeItems item = new CakeItems();
                    JSONObject feedObj = (JSONObject) cakes.get(i);
                    item.setTitle(feedObj.getString("title"));
                    item.setDesc(feedObj.getString("desc"));
                    item.setImage(feedObj.getString("image"));

                    cakeList.add(item);
                }

                cAdapter.notifyDataSetChanged();

                Toast.makeText(getActivity(), "Done: Request Completed.", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getActivity(), "Done: Request Failed!", Toast.LENGTH_SHORT).show();
            }

        }catch(JSONException e)
        {
            e.printStackTrace();
        }


    }
}

